const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');

puppeteer.use(StealthPlugin());

class TikTokScraper {
    constructor() {
        this.browser = null;
    }

    async initBrowser() {
        if (!this.browser) {
            this.browser = await puppeteer.launch({
                headless: true,
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-web-security',
                    '--disable-features=VizDisplayCompositor',
                    '--disable-dev-shm-usage',
                    '--no-first-run',
                    '--disable-extensions',
                    '--disable-plugins',
                    '--disable-images',
                    '--disable-background-timer-throttling',
                    '--disable-backgrounding-occluded-windows',
                    '--disable-renderer-backgrounding',
                    '--disable-background-networking',
                    '--disable-ipc-flooding-protection'
                ],
            });
        }
        return this.browser;
    }

    async closeBrowser() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
        }
    }

    async scrapeHashtag(hashtag = 'aitools') {
        let browser;
        try {
            browser = await this.initBrowser();
            const page = await browser.newPage();
            
            // Set user agent and viewport
            await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36');
            await page.setViewport({ width: 1280, height: 800 });

            const url = `https://www.tiktok.com/tag/${hashtag}`;
            console.log(`Navigating to: ${url}`);

            await page.goto(url, { 
                waitUntil: 'networkidle2',
                timeout: 30000 
            });

            // Wait for content to load with multiple fallback selectors
            try {
                await page.waitForSelector('div[data-e2e="challenge-item-list"]', { timeout: 15000 });
            } catch (error) {
                console.log('Primary selector not found, trying alternative selectors...');
                try {
                    await page.waitForSelector('[data-e2e="browse-video-desc"]', { timeout: 10000 });
                } catch (error2) {
                    console.log('Alternative selectors not found, proceeding with available content...');
                }
            }

            // Wait a bit more for dynamic content
            await new Promise(resolve => setTimeout(resolve, 3000));

            const results = await page.evaluate((hashtag) => {
                const output = [];
                
                // Try multiple selector strategies
                let cards = document.querySelectorAll('div[data-e2e="challenge-item-list"] > div');
                
                if (cards.length === 0) {
                    // Fallback selector
                    cards = document.querySelectorAll('[data-e2e="browse-video-desc"]').map(el => el.closest('div'));
                }

                if (cards.length === 0) {
                    // Another fallback
                    cards = document.querySelectorAll('a[href*="/video/"]').map(el => el.closest('div'));
                }

                cards.forEach((card, index) => {
                    if (!card) return;
                    
                    const linkEl = card.querySelector('a[href*="/video/"]') || card.querySelector('a');
                    const titleEl = card.querySelector('h3') || 
                                   card.querySelector('[data-e2e="browse-video-desc"]') ||
                                   card.querySelector('span[title]') ||
                                   card.querySelector('div[title]');
                    
                    const statsEl = card.querySelector('[data-e2e="browse-video-stats"]') ||
                                   card.querySelector('strong') ||
                                   card.querySelector('.view-count');

                    if (linkEl || titleEl) {
                        const title = titleEl ? titleEl.textContent.trim() || titleEl.getAttribute('title') : `TikTok video ${index + 1}`;
                        const link = linkEl ? (linkEl.href.startsWith('http') ? linkEl.href : `https://www.tiktok.com${linkEl.getAttribute('href')}`) : null;
                        const views = statsEl ? statsEl.textContent.trim() : 'N/A';

                        if (title && title.length > 0) {
                            output.push({
                                title: title,
                                link: link,
                                views: views,
                                hashtag: `#${hashtag}`,
                                platform: 'TikTok',
                                scraped_at: new Date().toISOString(),
                                monetization_angle: 'Create affiliate-style video, use case tutorial, or prompt pack around this tool'
                            });
                        }
                    }
                });

                return output.slice(0, 10);
            }, hashtag);

            await page.close();
            
            console.log(`Successfully scraped ${results.length} TikTok videos for #${hashtag}`);
            return results;

        } catch (error) {
            console.error('TikTok scraping error:', error);
            throw new Error(`Failed to scrape TikTok hashtag #${hashtag}: ${error.message}`);
        } finally {
            if (browser) {
                await this.closeBrowser();
            }
        }
    }
}

module.exports = new TikTokScraper();
