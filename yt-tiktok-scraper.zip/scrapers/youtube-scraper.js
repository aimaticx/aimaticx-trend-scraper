const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');

puppeteer.use(StealthPlugin());

class YouTubeScraper {
    constructor() {
        this.browser = null;
    }

    async initBrowser() {
        if (!this.browser) {
            this.browser = await puppeteer.launch({
                headless: true,
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-web-security',
                    '--disable-features=VizDisplayCompositor',
                    '--disable-dev-shm-usage',
                    '--no-first-run',
                    '--disable-extensions',
                    '--disable-plugins',
                    '--disable-images',
                    '--disable-background-timer-throttling',
                    '--disable-backgrounding-occluded-windows',
                    '--disable-renderer-backgrounding',
                    '--disable-background-networking',
                    '--disable-ipc-flooding-protection'
                ]
            });
        }
        return this.browser;
    }

    async closeBrowser() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
        }
    }

    async scrapeTrendingShorts() {
        let browser;
        try {
            browser = await this.initBrowser();
            const page = await browser.newPage();
            
            // Set user agent and viewport
            await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36');
            await page.setViewport({ width: 1280, height: 800 });

            console.log('Navigating to YouTube Trending...');
            await page.goto('https://www.youtube.com/feed/trending', { 
                waitUntil: 'domcontentloaded',
                timeout: 45000 
            });

            // Wait longer for dynamic content to load
            await new Promise(resolve => setTimeout(resolve, 8000));

            // Try multiple selector strategies with longer timeouts
            let hasContent = false;
            try {
                await page.waitForSelector('ytd-rich-section-renderer', { timeout: 20000 });
                hasContent = true;
            } catch (error) {
                console.log('Primary selector not found, trying alternative approach...');
                try {
                    await page.waitForSelector('ytd-rich-item-renderer', { timeout: 15000 });
                    hasContent = true;
                } catch (error2) {
                    console.log('Rich item renderer not found, trying video container...');
                    try {
                        await page.waitForSelector('ytd-video-renderer', { timeout: 10000 });
                        hasContent = true;
                    } catch (error3) {
                        console.log('Proceeding with available content...');
                    }
                }
            }

            // Additional wait for content stabilization
            await new Promise(resolve => setTimeout(resolve, 3000));

            const results = await page.evaluate(() => {
                const output = [];
                
                // Try multiple selector strategies to find videos
                let items = [];
                
                // Strategy 1: Rich item renderers (modern YouTube)
                items = document.querySelectorAll('ytd-rich-item-renderer');
                
                if (items.length === 0) {
                    // Strategy 2: Video renderers (alternative)
                    items = document.querySelectorAll('ytd-video-renderer');
                }
                
                if (items.length === 0) {
                    // Strategy 3: Any video links
                    items = document.querySelectorAll('a[href*="/watch"]');
                }

                console.log(`Found ${items.length} video items to process`);

                items.forEach((item, index) => {
                    try {
                        const titleEl = item.querySelector('#video-title') || 
                                       item.querySelector('a[aria-label]') ||
                                       item.querySelector('h3 a');
                        
                        const viewsEl = item.querySelector('#metadata-line span') ||
                                      item.querySelector('.style-scope.ytd-video-meta-block span') ||
                                      item.querySelector('span[aria-label*="views"]');
                        
                        const linkEl = item.querySelector('a#thumbnail') ||
                                      item.querySelector('#video-title') ||
                                      item.querySelector('a[href*="/watch"]') ||
                                      item.querySelector('a[href*="/shorts/"]');

                        const channelEl = item.querySelector('#channel-name a') ||
                                        item.querySelector('.ytd-channel-name a');

                        if (titleEl && linkEl) {
                            const title = titleEl.textContent?.trim() || titleEl.getAttribute('aria-label')?.trim();
                            const href = linkEl.getAttribute('href');
                            const link = href ? (href.startsWith('http') ? href : `https://www.youtube.com${href}`) : null;
                            const views = viewsEl ? viewsEl.textContent.trim() : 'N/A';
                            const channel = channelEl ? channelEl.textContent.trim() : 'Unknown';

                            if (title && title.length > 0 && link) {
                                // Determine if it's likely a Short (duration-based or URL-based)
                                const isShort = href?.includes('/shorts/') || 
                                              item.querySelector('[aria-label*="seconds"]') ||
                                              item.querySelector('[aria-label*="minute"]')?.textContent?.includes('1 minute') ||
                                              shortsSection !== null;

                                output.push({
                                    title: title,
                                    views: views,
                                    link: link,
                                    channel: channel,
                                    is_short: isShort,
                                    platform: 'YouTube',
                                    scraped_at: new Date().toISOString(),
                                    monetization_angle: isShort ? 
                                        'Create reaction video or commentary on this trending Short' : 
                                        'Create video reacting to or reviewing this trending content'
                                });
                            }
                        }
                    } catch (itemError) {
                        console.error(`Error processing item ${index}:`, itemError);
                    }
                });

                return output.slice(0, 15);
            });

            await page.close();
            
            console.log(`Successfully scraped ${results?.length || 0} YouTube trending videos`);
            return results || [];

        } catch (error) {
            console.error('YouTube scraping error:', error);
            throw new Error(`Failed to scrape YouTube trending: ${error.message}`);
        } finally {
            if (browser) {
                await this.closeBrowser();
            }
        }
    }
}

module.exports = new YouTubeScraper();
