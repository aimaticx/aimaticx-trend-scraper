class TrendScraperApp {
    constructor() {
        this.initializeEventListeners();
        this.loadFiles();
    }

    initializeEventListeners() {
        // YouTube scraper button
        document.getElementById('scrapeYouTube').addEventListener('click', () => {
            this.runYouTubeScraper();
        });

        // TikTok scraper button
        document.getElementById('scrapeTikTok').addEventListener('click', () => {
            const hashtag = document.getElementById('tiktokHashtag').value.trim() || 'aitools';
            this.runTikTokScraper(hashtag);
        });

        // Combined scraper button
        document.getElementById('scrapeCombined').addEventListener('click', () => {
            const hashtag = document.getElementById('combinedHashtag').value.trim() || 'aitools';
            this.runCombinedScraper(hashtag);
        });

        // Refresh files button
        document.getElementById('refreshFiles').addEventListener('click', () => {
            this.loadFiles();
        });

        // Handle Enter key in hashtag inputs
        document.getElementById('tiktokHashtag').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const hashtag = e.target.value.trim() || 'aitools';
                this.runTikTokScraper(hashtag);
            }
        });

        document.getElementById('combinedHashtag').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const hashtag = e.target.value.trim() || 'aitools';
                this.runCombinedScraper(hashtag);
            }
        });
    }

    showStatus(message, type = 'info', loading = false) {
        const statusCard = document.getElementById('statusCard');
        const statusContent = document.getElementById('statusContent');
        
        let iconClass = 'fas fa-info-circle';
        let cardClass = 'border-info';
        
        switch (type) {
            case 'success':
                iconClass = 'fas fa-check-circle';
                cardClass = 'border-success';
                break;
            case 'error':
                iconClass = 'fas fa-exclamation-triangle';
                cardClass = 'border-danger';
                break;
            case 'loading':
                iconClass = 'fas fa-spinner fa-spin';
                cardClass = 'border-primary';
                break;
        }

        statusContent.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="${iconClass} me-2 status-${type}"></i>
                <span>${message}</span>
                ${loading ? '<div class="spinner-border spinner-border-sm ms-2" role="status"></div>' : ''}
            </div>
        `;
        
        statusCard.className = `card ${cardClass} fade-in-up`;
        statusCard.classList.remove('d-none');
    }

    hideStatus() {
        document.getElementById('statusCard').classList.add('d-none');
    }

    async runYouTubeScraper() {
        const button = document.getElementById('scrapeYouTube');
        const originalText = button.innerHTML;
        
        try {
            // Disable button and show loading state
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Scraping...';
            
            this.showStatus('Starting YouTube Shorts scraping...', 'loading', true);

            const response = await fetch('/api/scrape/youtube', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const result = await response.json();

            if (result.success) {
                this.showStatus(`✅ ${result.message}`, 'success');
                await this.loadFiles(); // Refresh file list
            } else {
                this.showStatus(`❌ ${result.message}`, 'error');
            }

        } catch (error) {
            console.error('YouTube scraping error:', error);
            this.showStatus(`❌ Failed to scrape YouTube: ${error.message}`, 'error');
        } finally {
            // Re-enable button
            button.disabled = false;
            button.innerHTML = originalText;
            
            // Hide status after delay
            setTimeout(() => this.hideStatus(), 5000);
        }
    }

    async runTikTokScraper(hashtag) {
        const button = document.getElementById('scrapeTikTok');
        const originalText = button.innerHTML;
        
        try {
            // Disable button and show loading state
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Scraping...';
            
            this.showStatus(`Starting TikTok scraping for #${hashtag}...`, 'loading', true);

            const response = await fetch('/api/scrape/tiktok', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ hashtag })
            });

            const result = await response.json();

            if (result.success) {
                this.showStatus(`✅ ${result.message}`, 'success');
                await this.loadFiles(); // Refresh file list
            } else {
                this.showStatus(`❌ ${result.message}`, 'error');
            }

        } catch (error) {
            console.error('TikTok scraping error:', error);
            this.showStatus(`❌ Failed to scrape TikTok: ${error.message}`, 'error');
        } finally {
            // Re-enable button
            button.disabled = false;
            button.innerHTML = originalText;
            
            // Hide status after delay
            setTimeout(() => this.hideStatus(), 5000);
        }
    }

    async runCombinedScraper(hashtag) {
        const button = document.getElementById('scrapeCombined');
        const originalText = button.innerHTML;
        
        try {
            // Disable button and show loading state
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Ranking...';
            
            this.showStatus(`Starting combined scraping and ranking for #${hashtag}...`, 'loading', true);

            const response = await fetch('/api/scrape/combined', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ hashtag })
            });

            const result = await response.json();

            if (result.success) {
                const summary = result.summary;
                this.showStatus(`✅ Combined ranking complete: ${summary.total_videos} videos (${summary.tiktok_count} TikTok + ${summary.youtube_count} YouTube)`, 'success');
                await this.loadFiles(); // Refresh file list
            } else {
                this.showStatus(`❌ ${result.message}`, 'error');
            }

        } catch (error) {
            console.error('Combined scraping error:', error);
            this.showStatus(`❌ Failed to perform combined scraping: ${error.message}`, 'error');
        } finally {
            // Re-enable button
            button.disabled = false;
            button.innerHTML = originalText;
            
            // Hide status after delay
            setTimeout(() => this.hideStatus(), 5000);
        }
    }

    async loadFiles() {
        try {
            const response = await fetch('/api/data/files');
            const result = await response.json();

            if (result.success) {
                this.displayFiles(result.files);
            } else {
                console.error('Failed to load files:', result.message);
            }
        } catch (error) {
            console.error('Error loading files:', error);
        }
    }

    displayFiles(files) {
        const container = document.getElementById('resultsContainer');
        
        if (!files || files.length === 0) {
            container.innerHTML = `
                <div class="text-center text-muted py-5">
                    <i class="fas fa-inbox fa-3x mb-3"></i>
                    <p>No scraped data yet. Start by running a scraper above.</p>
                </div>
            `;
            return;
        }

        const fileList = files.map(file => {
            const platformBadge = file.platform === 'YouTube' ? 
                '<span class="badge platform-badge platform-youtube">YouTube</span>' :
                '<span class="badge platform-badge platform-tiktok">TikTok</span>';
            
            const sizeKB = Math.round(file.size / 1024);
            const createdDate = new Date(file.created).toLocaleString();

            return `
                <div class="file-item">
                    <div class="d-flex justify-content-between align-items-start">
                        <div class="flex-grow-1">
                            <h6 class="mb-1">
                                ${platformBadge}
                                <span class="ms-2">${file.filename}</span>
                            </h6>
                            <div class="file-meta">
                                <i class="fas fa-calendar-alt me-1"></i>
                                ${createdDate}
                                <span class="mx-2">•</span>
                                <i class="fas fa-file-alt me-1"></i>
                                ${sizeKB} KB
                            </div>
                        </div>
                        <button class="btn btn-outline-primary btn-sm" onclick="app.viewFileData('${file.filename}')">
                            <i class="fas fa-eye me-1"></i>
                            View Data
                        </button>
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = fileList;
    }

    async viewFileData(filename) {
        try {
            const response = await fetch(`/api/data/${filename}`);
            const result = await response.json();

            if (result.success) {
                this.displayDataModal(filename, result.data);
            } else {
                this.showStatus(`❌ Failed to load file: ${result.message}`, 'error');
            }
        } catch (error) {
            console.error('Error loading file data:', error);
            this.showStatus(`❌ Error loading file: ${error.message}`, 'error');
        }
    }

    displayDataModal(filename, data) {
        const modal = new bootstrap.Modal(document.getElementById('dataModal'));
        const modalContent = document.getElementById('dataModalContent');
        
        // Update modal title
        document.querySelector('#dataModal .modal-title').textContent = `Data from ${filename}`;

        if (!data || data.length === 0) {
            modalContent.innerHTML = `
                <div class="text-center text-muted py-4">
                    <i class="fas fa-exclamation-circle fa-2x mb-3"></i>
                    <p>No data found in this file.</p>
                </div>
            `;
        } else {
            const tableRows = data.map((item, index) => {
                const platformBadge = item.platform === 'YouTube' ? 
                    '<span class="badge platform-badge platform-youtube">YouTube</span>' :
                    '<span class="badge platform-badge platform-tiktok">TikTok</span>';

                return `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${platformBadge}</td>
                        <td class="title-cell" title="${this.escapeHtml(item.title || 'N/A')}">
                            ${this.escapeHtml(item.title || 'N/A')}
                        </td>
                        <td>${item.views || 'N/A'}</td>
                        <td class="link-cell">
                            ${item.link ? `<a href="${item.link}" target="_blank" rel="noopener" class="text-decoration-none">
                                <i class="fas fa-external-link-alt me-1"></i>View
                            </a>` : 'N/A'}
                        </td>
                        <td>
                            <div class="monetization-angle">
                                ${this.escapeHtml(item.monetization_angle || 'No suggestion')}
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');

            modalContent.innerHTML = `
                <div class="mb-3">
                    <strong>Total items:</strong> ${data.length}
                    <span class="mx-2">•</span>
                    <strong>Platform:</strong> ${data[0]?.platform || 'Unknown'}
                </div>
                <div class="table-responsive">
                    <table class="table table-striped data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Platform</th>
                                <th>Title</th>
                                <th>Views</th>
                                <th>Link</th>
                                <th>Monetization Angle</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tableRows}
                        </tbody>
                    </table>
                </div>
            `;
        }

        modal.show();
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new TrendScraperApp();
});
